#include <iostream>
#include <string>
#include <fstream>
#include <map>
#include <cctype>

using namespace std;

int ProductFile() { // Used to write to file ProductFile.txt
	ofstream outFS; // Reader for file

	outFS.open("ProductFile.txt"); // Output file

	if (!outFS.is_open()) { // Checking file is open
		cout << "Failed" << endl;
		return 1;
	}

	// Writing every entry to ProductFile.txt
	outFS << "Spinach" << endl;
	outFS << "Radishes" << endl;
	outFS << "Broccoli" << endl;
	outFS << "Peas" << endl;
	outFS << "Cranberries" << endl;
	outFS << "Broccoli" << endl;
	outFS << "Potatoes" << endl;
	outFS << "Cucumbers" << endl;
	outFS << "Radishes" << endl;
	outFS << "Cranberries" << endl;
	outFS << "Peaches" << endl;
	outFS << "Zucchini" << endl;
	outFS << "Potatoes" << endl;
	outFS << "Cranberries" << endl;
	outFS << "Cantaloupe" << endl;
	outFS << "Beets" << endl;
	outFS << "Cauliflower" << endl;
	outFS << "Cranberries" << endl;
	outFS << "Peas" << endl;
	outFS << "Zucchini" << endl;
	outFS << "Peas" << endl;
	outFS << "Onions" << endl;
	outFS << "Potatoes" << endl;
	outFS << "Cauliflower" << endl;
	outFS << "Spinach" << endl;
	outFS << "Radishes" << endl;
	outFS << "Onions" << endl;
	outFS << "Zucchini" << endl;
	outFS << "Cranberries" << endl;
	outFS << "Peaches" << endl;
	outFS << "Yams" << endl;
	outFS << "Zucchini" << endl;
	outFS << "Apples" << endl;
	outFS << "Cucumbers" << endl;
	outFS << "Broccoli" << endl;
	outFS << "Cranberries" << endl;
	outFS << "Beets" << endl;
	outFS << "Peas" << endl;
	outFS << "Cauliflower" << endl;
	outFS << "Potatoes" << endl;
	outFS << "Cauliflower" << endl;
	outFS << "Celery" << endl;
	outFS << "Cranberries" << endl;
	outFS << "Limes" << endl;
	outFS << "Cranberries" << endl;
	outFS << "Broccoli" << endl;
	outFS << "Spinach" << endl;
	outFS << "Broccoli" << endl;
	outFS << "Garlic" << endl;
	outFS << "Cauliflower" << endl;
	outFS << "Pumpkins" << endl;
	outFS << "Celery" << endl;
	outFS << "Peas" << endl;
	outFS << "Potatoes" << endl;
	outFS << "Yams" << endl;
	outFS << "Zucchini" << endl;
	outFS << "Cranberries" << endl;
	outFS << "Cantaloupe" << endl;
	outFS << "Zucchini" << endl;
	outFS << "Pumpkins" << endl;
	outFS << "Cauliflower" << endl;
	outFS << "Yams" << endl;
	outFS << "Pears" << endl;
	outFS << "Peaches" << endl;
	outFS << "Apples" << endl;
	outFS << "Zucchini" << endl;
	outFS << "Cranberries" << endl;
	outFS << "Zucchini" << endl;
	outFS << "Garlic" << endl;
	outFS << "Broccoli" << endl;
	outFS << "Garlic" << endl;
	outFS << "Onions" << endl;
	outFS << "Spinach" << endl;
	outFS << "Cucumbers" << endl;
	outFS << "Cucumbers" << endl;
	outFS << "Garlic" << endl;
	outFS << "Spinach" << endl;
	outFS << "Peaches" << endl;
	outFS << "Cucumbers" << endl;
	outFS << "Broccoli" << endl;
	outFS << "Zucchini" << endl;
	outFS << "Peas" << endl;
	outFS << "Celery" << endl;
	outFS << "Cucumbers" << endl;
	outFS << "Celery" << endl;
	outFS << "Yams" << endl;
	outFS << "Garlic" << endl;
	outFS << "Cucumbers" << endl;
	outFS << "Peas" << endl;
	outFS << "Beets" << endl;
	outFS << "Yams" << endl;
	outFS << "Peas" << endl;
	outFS << "Apples" << endl;
	outFS << "Peaches" << endl;
	outFS << "Garlic" << endl;
	outFS << "Celery" << endl;
	outFS << "Garlic" << endl;
	outFS << "Cucumbers" << endl;
	outFS << "Garlic" << endl;
	outFS << "Apples" << endl;
	outFS << "Celery" << endl;
	outFS << "Zucchini" << endl;
	outFS << "Cucumbers" << endl;
	outFS << "Onions" << endl;

	outFS.close(); // Closing ProductFile.txt
}
class CornerGrocer { // Class CornerGrocer

private: // The user has no reason to see these
	
	ifstream foodFile;
	map<string, int> frequency;

public:

	void Opening() { // Menu options

		cout << "**************************************" << endl;
		cout << "* 1 - Input a Product                *" << endl;
		cout << "* 2 - Print Product List             *" << endl;
		cout << "* 3 - Print Product List Histogram   *" << endl;
		cout << "* 4 - Exit Program                   *" << endl;
		cout << "**************************************" << endl;
		cout << endl;
		cout << "What would you like to do?" << endl;
		cout << endl;
	}

	void OptionOne() { // Option 1 function
		ifstream foodFile;
		string productName;
		map<string, int> frequency;
		
		cout << "Opening Product File." << endl;
		cout << endl;

		foodFile.open("ProductFile.txt"); // Opening file
		if (!foodFile.is_open()) { // Checking if file is open
			cout << "Failed." << endl;
		}

		while (foodFile >> productName) { // Reading each name in file
			if (frequency.count(productName)) { // Add 1 to frequency if product exists
				frequency[productName] += 1;
			}
			else {
				frequency.emplace(productName, 1); // If not, creates with value of 1 frequency
			}
		}

		cout << "What item would you like to see the frequency of?" << endl; // User prompted
		cin >> productName; // User inputs product's name
		productName[0] = toupper(productName[0]); // Captilize first letter of input
		cout << endl;
		cout << productName << " " << frequency[productName] << endl; // Output name and frequency of desired product
		foodFile.close(); // File close
	}

	void OptionTwo() { // Option 2 function
		ifstream foodFile;
		string productName;
		map<string, int> frequency;

		cout << "Opening Product File." << endl;
		cout << endl;

		foodFile.open("ProductFile.txt"); // Opening file
		if (!foodFile.is_open()) { // Checking if file is open
			cout << "Failed." << endl;
		}

		while (foodFile >> productName) { // Reading each name in file
			if (frequency.count(productName)) { // Add 1 to frequency if product exists
				frequency[productName] += 1;
			}
			else {
				frequency.emplace(productName, 1); // If not, creates with value of 1 frequency
			}
		}

		for (auto productListFrequency : frequency) { // Outputs entire list with name followed by frequency
			cout << productListFrequency.first << " " << productListFrequency.second << endl;
		}
		foodFile.close();
	}

	void OptionThree() {
		ifstream foodFile;
		string productName;
		map<string, int> frequency;

		cout << "Opening Product File." << endl;
		cout << endl;

		foodFile.open("ProductFile.txt"); // Opening file
		if (!foodFile.is_open()) { // Checking if file is open
			cout << "Failed." << endl;
		}

		while (foodFile >> productName) { // Reading each name in file
			if (frequency.count(productName)) { // Add 1 to frequency if product exists
				frequency[productName] += 1;
			}
			else {
				frequency.emplace(productName, 1); // If not, creates with value of 1 frequency
			}
		}

		for (auto productListFrequency : frequency) { // Output products names and frequencies
			cout << productListFrequency.first << " ";
			for (int i = 0; i < productListFrequency.second; ++i) { // Changes int frequency to "*"
				cout << "*";
			}
			cout << endl;
		}
		foodFile.close(); // Close file
		cout << endl;
	}
};

int main() { // Main

	CornerGrocer cg; // Acknowledging CornerGrocer class as object cg

	ifstream foodFile;
	string productName;
	int option;
	map<string, int> frequency;

	//ProductFile(); // How I was able to make the Product File

	cg.Opening(); // Calls Opening function

	cin >> option; // User inputs choice from menu

	while (true) {
		if (option == 1) { // If option 1
			cg.OptionOne(); // Calls OptionOne function
			cout << endl;
			cg.Opening();
			cin >> option; // Allows user to pick again
		}
		else if (option == 2) { // If option 2
			cg.OptionTwo(); // Calls OptionTwo function
			cout << endl;
			cg.Opening();
			cin >> option; // Allows user to pick again
		}
		else if (option == 3) { // If option 3
			cg.OptionThree(); // Calls OptionThree function
			cout << endl;
			cg.Opening();
			cin >> option; // Allows user to pick again
		}
		else if (option == 4) { // If option 4
			cout << "Goodbye." << endl;
			break; // Leaves option loop
		}
		else {
			cout << "Unknown Option." << endl; // Any other input displays this message and lets the user choose a valid option.
			cout << endl;
			cg.Opening();
			cin >> option; // Input option to do more.
		}
	}
	cout << endl;
	foodFile.close();
	return 0;
}